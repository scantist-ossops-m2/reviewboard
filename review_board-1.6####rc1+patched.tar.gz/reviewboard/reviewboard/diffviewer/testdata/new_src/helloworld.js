/*
 * Prints "Hello world!"
 */
function helloWorld()
{
    alert("Hello world!");
}

var data = {
	/*
	 * Prints "Hello world!"
	 */
	helloWorld2: function()
	{
		alert("Hello world!");
	}
}

var helloWorld3 = function()
{
	alert("Hello world!");
}
