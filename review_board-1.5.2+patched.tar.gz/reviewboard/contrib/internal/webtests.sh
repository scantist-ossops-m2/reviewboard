#!/bin/sh

./reviewboard/manage.py test -- webtests
