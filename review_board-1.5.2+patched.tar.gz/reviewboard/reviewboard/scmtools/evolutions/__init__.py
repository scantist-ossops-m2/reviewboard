SEQUENCE = [
    'bugzilla_url_charfield',
    'repository_raw_file_url',
    'repository_visible',
    'repository_path_length_255',
]
