# Hello World class
class HelloWorld
	# Prints Hello World
	def helloWorld()
		puts "Hello world!"
	end
end
