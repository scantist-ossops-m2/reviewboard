#include <stdio.h>

int
main()
{
	printf("foo bar\n");
	return 0;
}
