SEQUENCE = [
    'change_descriptions',
    'last_review_timestamp',
    'shipit_count',
    'default_reviewer_repositories',
    'null_repository',
]
