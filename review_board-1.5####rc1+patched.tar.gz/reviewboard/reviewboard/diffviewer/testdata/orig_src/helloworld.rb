class HelloWorld
	def helloWorld
		puts "Hello world!"
	end
end
