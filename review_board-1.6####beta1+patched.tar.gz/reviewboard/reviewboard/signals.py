from django.dispatch import Signal


initializing = Signal()
