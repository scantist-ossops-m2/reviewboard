@interface MyClass : Object
- (void) sayHello;
@end

@implementation MyClass
- (void) sayHello {
	printf("Hello world!");
}
@end
