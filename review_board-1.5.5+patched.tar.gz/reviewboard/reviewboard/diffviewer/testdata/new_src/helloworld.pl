# Prints Hello World
sub helloWorld
{
	print "Hello world!"
}
