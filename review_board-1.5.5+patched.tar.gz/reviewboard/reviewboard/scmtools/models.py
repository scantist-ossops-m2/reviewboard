from django.core.exceptions import ImproperlyConfigured
from django.db import models

from reviewboard.scmtools.managers import RepositoryManager


class Tool(models.Model):
    name = models.CharField(max_length=32, unique=True)
    class_name = models.CharField(max_length=128, unique=True)

    supports_authentication = property(
        lambda x: x.get_scmtool_class().supports_authentication)
    supports_raw_file_urls = property(
        lambda x: x.get_scmtool_class().supports_raw_file_urls)

    def __unicode__(self):
        return self.name

    def get_scmtool_class(self):
        path = self.class_name
        i = path.rfind('.')
        module, attr = path[:i], path[i+1:]

        try:
            mod = __import__(module, {}, {}, [attr])
        except ImportError, e:
            raise ImproperlyConfigured, \
                'Error importing SCM Tool %s: "%s"' % (module, e)

        try:
            return getattr(mod, attr)
        except AttributeError:
            raise ImproperlyConfigured, \
                'Module "%s" does not define a "%s" SCM Tool' % (module, attr)

    class Meta:
        ordering = ("name",)


class Repository(models.Model):
    name = models.CharField(max_length=64, unique=True)
    path = models.CharField(max_length=255, unique=True)
    mirror_path = models.CharField(max_length=255, blank=True)
    raw_file_url = models.CharField(max_length=255, blank=True)
    username = models.CharField(max_length=32, blank=True)
    password = models.CharField(max_length=128, blank=True)
    tool = models.ForeignKey(Tool, related_name="repositories")
    bug_tracker = models.CharField(max_length=256, blank=True)
    encoding = models.CharField(max_length=32, blank=True)
    visible = models.BooleanField(default=True)

    objects = RepositoryManager()

    def get_scmtool(self):
        cls = self.tool.get_scmtool_class()
        return cls(self)


    def is_mutable_by(self, user):
        """Returns whether or not the user can modify or delete the repository.

        The repository is mutable by the user if the user is an administrator
        with proper permissions.
        """
        return user.has_perm('scmtools.change_repository')

    def __unicode__(self):
        return self.name


    class Meta:
        verbose_name_plural = "Repositories"
