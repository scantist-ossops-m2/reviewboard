int
main()
{
	printf("foo\n");
}
