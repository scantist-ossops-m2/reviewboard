<?php
/*
 * Hello World class
 */
class HelloWorld
{
	/*
	 * Prints Hello World
	 */
	function helloWorld()
	{
		print "Hello world!";
	}
}
?>
