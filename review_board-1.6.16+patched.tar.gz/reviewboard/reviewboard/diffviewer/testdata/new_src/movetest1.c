/*
 * movetest1.c
 */


// ----


int
dummy(int param1, int param2)
{
	if (1) {
		// whatever
	}
}


/*
 * Says goodbye
 */
void
say_goodbye()
{
	printf("Goodbye!\n");
}


void
say_hello()
{
	printf("Hello world!\n");
}


int
main(int argc, char **argv)
{
	say_hello();
	return 0;
}
/*
 *
 */
