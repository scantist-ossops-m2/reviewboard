SEQUENCE = [
    'bugzilla_url_charfield',
    'repository_raw_file_url',
    'repository_visible',
    'repository_path_length_255',
    'localsite',
    'repository_access_control',
    'group_site',
    'repository_hosting_accounts',
    'repository_extra_data_null',
]
