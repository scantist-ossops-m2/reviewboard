class AuthorizationError(Exception):
    pass
