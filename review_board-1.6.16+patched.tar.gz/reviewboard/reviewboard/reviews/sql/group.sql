CREATE
	INDEX group_users__group_user
	ON reviews_group_users
	(group_id, user_id);
