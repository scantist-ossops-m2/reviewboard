/*
 * movetest1.c
 */


/*
 *
 */
// ----


/*
 * Says hello
 */
void
say_hello()
{
	printf("Hello world!\n");
}


int
dummy(int param1, int param2)
{
	if (1) {
		// whatever
	}
}


void
say_goodbye()
{
	printf("Goodbye!\n");
}


int
main(int argc, char **argv)
{
	say_hello();
	return 0;
}
