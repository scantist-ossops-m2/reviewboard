SEQUENCE = [
    'add_parent_diffs',
    'filediff_filenames_1024_chars',
    'diffset_basedir',
    'filediff_status',
]
