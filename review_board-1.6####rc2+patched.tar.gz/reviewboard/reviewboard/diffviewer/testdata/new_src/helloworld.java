/*
 * The Hello World class.
 */
class HelloWorld
{
	/*
	 * The main function in this class.
	 */
	public static void main(String[] args)
	{
		/*
		 * Print "Hello world!" to the screen.
		 */
		System.out.println("Hello world!");
	}
}
