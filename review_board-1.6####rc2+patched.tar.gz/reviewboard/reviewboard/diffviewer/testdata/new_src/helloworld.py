class HelloWorld:
    """The Hello World class"""

    def main(self):
        """The main function in this class."""

        # Prints "Hello world!" to the screen.
        print "Hello world!"

