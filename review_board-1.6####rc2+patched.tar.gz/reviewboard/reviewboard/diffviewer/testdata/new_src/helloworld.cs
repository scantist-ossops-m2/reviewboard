/*
 * The Hello World class.
 */
public class HelloWorld
{
	/*
	 * The main function in this class.
	 */
	public static void Main()
	{
		/*
		 * Print "Hello world!" to the screen.
		 */
		System.Console.WriteLine("Hello world!");
	}
}
