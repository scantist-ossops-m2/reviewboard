function helloWorld() {
    alert("Hello world!");
}

var data = {
	helloWorld2: function() {
		alert("Hello world!");
	}
}

var helloWorld3 = function() {
	alert("Hello world!");
}
