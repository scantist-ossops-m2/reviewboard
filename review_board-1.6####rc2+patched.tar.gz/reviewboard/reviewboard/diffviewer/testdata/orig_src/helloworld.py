class HelloWorld:
    def main(self):
        print "Hello World"
