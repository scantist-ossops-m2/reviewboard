<?php
class HelloWorld {
	function helloWorld() {
		print "Hello world!";
	}
}
?>
