SEQUENCE = [
    'change_descriptions',
    'last_review_timestamp',
    'shipit_count',
    'default_reviewer_repositories',
    'null_repository',
    'localsite',
    'group_incoming_request_count',
    'group_invite_only',
    'group_visible',
    'default_reviewer_local_site',
    'add_issues_to_comments',
    'file_attachments',
]
