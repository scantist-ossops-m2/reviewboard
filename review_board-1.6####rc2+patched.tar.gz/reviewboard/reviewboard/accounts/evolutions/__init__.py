SEQUENCE = [
    'is_private',
]
